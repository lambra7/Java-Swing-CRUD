/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TIPIv4;

/**
 *
 * @author Sergio Novais
 */
public class Produto {
    private String nome;
    private String ncm;
    private String valor;
    private String aliq;

    public Produto() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNcm() {
        return ncm;
    }

    public void setNcm(String ncm) {
        this.ncm = ncm;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getAliq() {
        return aliq;
    }

    public void setAliq(String aliq) {
        this.aliq = aliq;
    }
    
    
    
}
